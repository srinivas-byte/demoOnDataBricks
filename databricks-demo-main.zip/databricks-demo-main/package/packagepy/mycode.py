def custommessage(name):
    print("Welcome to Python Package!"+name)